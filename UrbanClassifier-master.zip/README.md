### Инструкция по запуску проекта Django на сервере

*За основу была взята инструкция из https://www.8host.com/blog/razvyortyvanie-lokalnogo-prilozheniya-django-na-vps/

##### 1. Обновление пакетов:
- Перед развертыванием рекомендуется обновить список пакетов системы. Для Linux:
  - `sudo apt-get update`
  - `sudo apt-get upgrade`
  
##### 2. Настройка virtualenv:
- Необходимо сделать настройку виртуального окружения, или virtualenv:
  - `sudo apt-get install python-virtualenv`

- Теперь нужно создать virtualenv (или виртуальную среду), чтобы разместить и постоянно хранить в ней Django и другие пакеты Python:
  - `sudo virtualenv /project/myenv`

*В папке /project (имя каталога может быть любым) будет храниться сам проект и папка виртуального окружения /myenv.

- Теперь нужно активировать virtualenv перед установкой пакетов:
  - `source /project/myenv/bin/activate`
  
##### 3. Проверка БД
В проекте используется PostgreSQL. Файл настройки конфигурации будет получен из репозитория GIT

##### 4. Настройка VPS
Необходимо настроить веб-сервер.
Здесь представлена настройка для NGINX - https://www.8host.com/blog/razvyortyvanie-lokalnogo-prilozheniya-django-na-vps/

##### 5. Клонирование репозитория из GIT на сервер
- Необходимо перейти в папку /project (в нем уже должна быть папка /myenv)
  - `cd project`
- Далее создать каталог для хранения файлов проекта и перейти в него:
  - `mkdir UrbanClassifier`
  - `cd UrbanClassifier`
- Если GIT не установлен на сервере, то выполнить:
  - `sudo apt-get install git`
- Клонировать в папку /UrbanClassifier проект из GIT:
  - `git clone https://github.com/PeetaBegen/UrbanClassifier.git .`

##### 6. Установка необходимых пакетов Python
- В папке /UrbanClassifier выполнить команду для установки всех необходимых пакетов (в том числе Django) из файла requirements.txt:
  - `pip install -r requirements.txt`
  
- Скопировать из папки проекта файл UrbanClassifier/static/fasttext-social-network-model.bin
в папку библиотеки для работы с анализом тональности: /myenv/Lib/site-packages/dostoevsky/data/models/
  
##### 7. Настройка приложения: БД, production
- Необходимо откорректировать файл UrbanClassifier/UrbanClassifier/settings.py:
  - Установить следующее значение для опции DEBUG: `DEBUG = False`
  - Затем отредактировать настройки БД, указав имя БД, имя пользователя и пароль:
    - `DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'urban_classifier',
        'USER': 'u_admin',
        'PASSWORD': 'u_admin',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}`
  - Сохранить и закрыть файл
  - В терминале выполнить команды по миграции данных в БД - сначала по проверке новых миграций, а затем запустить миграции:
    - `python manage.py makemigrations`
    - `python manage.py migrate`
- Откорректировать файл UrbanClassifier/templates/index.html:
  - В блоке скрипта для функций make_prediction() и download_csv() поменять значение переменной url на адрес сервера 

##### 8. Запуск приложения
- Чтобы запустить веб-приложение, необходимо в терминале ввести команду:
  - `python manage.py runserver`