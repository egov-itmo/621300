from django.apps import AppConfig


class ClassificationConfig(AppConfig):
    name = 'classification'
