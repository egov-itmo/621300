import json
import os
import pickle
import re

import classification.sentiment_analysis as sentiment_analysis
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pymorphy2
import seaborn
from UrbanClassifier.settings import BASE_DIR, STATIC_URL
from keras import Sequential
from keras.callbacks import EarlyStopping
from keras.layers import LSTM
from keras.layers.core import Dense, Dropout
from keras.layers.embeddings import Embedding
from keras.preprocessing.text import Tokenizer
from keras.utils import to_categorical
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from tqdm import tqdm


def prepare_data(filename):
    print('Инициализириуем данные...')
    with open(filename, errors='ignore', encoding='utf-8') as file:
        dfs = [pd.read_csv(file, delimiter=';')]
    print('Всего данных: {}'.format(len(dfs[0])))

    p = pd.concat(dfs, ignore_index=True, sort=True)

    print('Загружаем данные...')
    # удаляем записи, где тип объекта="не определено"
    p = p.replace({'Тип объекта': {'не определено': np.NaN}}).dropna(subset=['Тип объекта'])

    raw_X = [str(item) for item in p['Текст']]
    raw_Y = [str(item) for item in p['Тип объекта']]

    print('Загружено данных: {}'.format(len(raw_X)))

    # очищаем и нормализуем данные
    print('Очищаем данные...')
    X = clear_data(raw_X)

    # переводим названия категорий в числа
    categories = {'Здание': 1, 'Двор': 2, 'Дорога': 3, 'Территория озеленения': 4,
                  'Малая архитектурная форма': 5, 'Водный объект': 6, }
    raw_Y = [categories.get(i) for i in raw_Y]

    # разбиваем массив на обучающую и тестовую выборки в соотношении 80/20
    x_train, x_test, y_train, y_test = train_test_split(X, raw_Y, test_size=0.20)

    print('Преобразуем данные...')
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(x_train)

    x_train = tokenizer.texts_to_matrix(x_train, mode='tfidf')
    x_test = tokenizer.texts_to_matrix(x_test, mode='tfidf')

    # Получаем максимальный размер измерений
    MAX_LENGTH = 200
    maxlen = len(max(x_train, key=len))
    if maxlen > MAX_LENGTH:
        maxlen = MAX_LENGTH
    #
    # # дополняем все предложения до размерности maxlen
    # x_train = pad_sequences(x_train, padding='post', maxlen=maxlen)
    # x_test = pad_sequences(x_test, padding='post', maxlen=maxlen)

    # переводим метки классов в матрицу one-hot
    y_train = to_categorical(y_train, dtype='int32')
    y_test = to_categorical(y_test, dtype='int32')

    # сохраняем метаданные для дальнейшего использования
    metadata = {'data_size': len(raw_X), 'categories': categories, 'maxlen': maxlen}

    print('Сохраняем обработанные данные...')
    with open('classification/data/raw_data.pkl', 'wb') as file:
        pickle.dump(raw_X, file)

    with open('classification/data/train_data.pkl', 'wb') as file:
        pickle.dump(x_train, file)

    with open('classification/data/train_labels.pkl', 'wb') as file:
        pickle.dump(y_train, file)

    with open('classification/data/test_data.pkl', 'wb') as file:
        pickle.dump(x_test, file)

    with open('classification/data/test_labels.pkl', 'wb') as file:
        pickle.dump(y_test, file)

    with open('classification/data/tokenizer.pkl', 'wb') as file:
        pickle.dump(tokenizer, file)

    with open('classification/data/metadata.txt', 'w') as file:
        json.dump(metadata, file)


def clear_data(X):
    morph = pymorphy2.MorphAnalyzer()
    T = []
    for line in tqdm(X):
        # оставляем только кириллицу и пробелы
        l = re.sub(r'[^а-яА-Я -]+', ' ', line)
        # приводим слова к нормальной форме
        words = l.split(' ')
        sentence = ''
        for word in words:
            if len(word) > 1:  # исключаем одиночные символы
                sentence += morph.parse(word)[0].normal_form
                sentence += ' '
        T.append(sentence)
    return T


def load_data():
    """

    :return: x_train, y_train, x_test, y_test, tokenizer, categories
    """
    # загружаем необходимые данные
    path = BASE_DIR + STATIC_URL + 'classification/data/'
    with open(path + 'train_data.pkl', 'rb') as file:
        x_train = pickle.load(file)

    with open(path + 'train_labels.pkl', 'rb') as file:
        y_train = pickle.load(file)

    with open(path + 'test_data.pkl', 'rb') as file:
        x_test = pickle.load(file)

    with open(path + 'test_labels.pkl', 'rb') as file:
        y_test = pickle.load(file)

    with open(path + 'tokenizer.pkl', 'rb') as file:
        tokenizer = pickle.load(file)

    with open(path + 'metadata.txt', encoding='utf-8') as json_file:
        metadata = json.load(json_file)
    categories = metadata['categories']  # type: dict

    return x_train, y_train, x_test, y_test, tokenizer, categories


def lstm():
    print('Строим модель LSTM...')
    # загружаем необходимые данные
    x_train, y_train, x_test, y_test, tokenizer, categories = load_data()
    path = BASE_DIR + STATIC_URL

    # Обратный вызов для функции ранней остановки при val_loss. Если val_loss
    # не снижается в двух последовательных попытках, прекратить обучение.
    callbacks = [EarlyStopping(monitor='val_loss', patience=2)]

    vocab_size = len(tokenizer.word_index) + 1

    # структура модели
    model = Sequential()
    model.add(Embedding(vocab_size, 128))
    model.add(LSTM(128, dropout=0.2, recurrent_dropout=0.2))
    model.add(Dense(y_train.shape[1], activation='softmax'))

    model.compile(loss='categorical_crossentropy', optimizer='rmsprop', metrics=['acc'])
    print(model.summary())
    # -----------------------------------------

    history = model.fit(x_train, y_train, batch_size=128, epochs=3, verbose=1, validation_data=(x_test, y_test),
                        callbacks=callbacks)

    # сохраняем обученную модель и историю обучения
    with open(path + 'classification/models/LSTM.md', 'wb') as file:
        pickle.dump(model, file)
    with open(path + 'classification/models/LSTM_history.md', 'wb') as file:
        pickle.dump(history, file)


def mlp():
    print('Строим модель MLP...')
    # загружаем необходимые данные
    x_train, y_train, x_test, y_test, tokenizer, categories = load_data()
    path = BASE_DIR + STATIC_URL

    # Обратный вызов для функции ранней остановки при val_loss. Если val_loss
    # не снижается в двух последовательных попытках, прекратить обучение.
    callbacks = [EarlyStopping(monitor='val_loss', patience=2)]

    # структура модели
    model = Sequential()
    model.add(Dense(128, activation='relu', input_dim=x_train.shape[1]))
    model.add(Dropout(0.2))
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(y_train.shape[1], activation='softmax'))

    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['acc'])
    print(model.summary())
    # -----------------------------------------

    history = model.fit(x_train, y_train, batch_size=128, epochs=50, verbose=1, validation_data=(x_test, y_test),
                        callbacks=callbacks)

    # сохраняем обученную модель и историю обучения
    with open(path + 'classification/models/MLP.md', 'wb') as file:
        pickle.dump(model, file)
    with open(path + 'classification/models/MLP_history.md', 'wb') as file:
        pickle.dump(history, file)


def get_report(model_name):
    print('Строим отчет...')
    # загружаем необходимые данные
    x_train, y_train, x_test, y_test, tokenizer, categories = load_data()
    path = BASE_DIR + STATIC_URL
    with open(path + 'classification/models/{}.md'.format(model_name), 'rb') as file:
        model = pickle.load(file)

    # получение отчета классификации и матрицы неточностей
    y_predicted = model.predict(x_test)
    y_predicted = np.argmax(y_predicted, axis=1)
    y_test = np.argmax(y_test, axis=1)

    categories = [i for i in categories.keys()]

    with open(path + 'classification/results/classification_report_{}.txt'.format(model_name), 'w',
              encoding='utf-8') as file:
        file.write(classification_report(y_test, y_predicted, target_names=categories))

    # Визуализация отчета
    cm = confusion_matrix(y_test, y_predicted)
    categories = ['Здание', 'Двор', 'Дорога', 'Тер. озел.', 'МАФ', 'Вод. объект']
    df_cm = pd.DataFrame(cm, index=[i for i in categories],
                         columns=[i for i in categories])
    plt.figure(dpi=300, figsize=(11, 8), clear=True)
    seaborn.set(font_scale=1.3)
    heatmap = seaborn.heatmap(df_cm, annot=True, linewidths=.5, fmt='d', cmap='Blues', square=True)
    heatmap.set_yticklabels(heatmap.get_yticklabels(), rotation=0)
    plt.savefig(path + 'classification/results/confusion_matrix_{}.png'.format(model_name))
    plt.clf()


def visualization(model_name):
    print('Визуализация...')
    # загружаем необходимые данные
    path = BASE_DIR + STATIC_URL
    with open(path + 'classification/models/{}_history.md'.format(model_name), 'rb') as file:
        history = pickle.load(file)

    plt.figure(dpi=200, clear=True)
    seaborn.set(font_scale=1)
    plt.plot(history.history['acc'], marker='o')
    plt.plot(history.history['val_acc'], marker='o')

    plt.title('Точность модели (accuracy)')
    plt.ylabel('Точность')
    plt.xlabel('Эпоха')
    plt.legend(['Обучение', 'Проверка'], loc='upper left')
    plt.savefig(path + 'classification/results/accuracy_{}.png'.format(model_name))
    plt.clf()

    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])

    plt.title('Функция потерь (loss function)')
    plt.ylabel('Потери')
    plt.xlabel('Эпоха')
    plt.legend(['Обучение', 'Проверка'], loc='upper left')
    plt.savefig(path + 'classification/results/loss_{}.png'.format(model_name))
    plt.clf()


def predict_all_and_save(filename, model_name):
    """

    :param filename:
    :param model_name:
    :return: new dataframe with types and sentiment
    """
    # загружаем необходимые данные
    path = BASE_DIR + STATIC_URL
    x_train, y_train, x_test, y_test, tokenizer, categories = load_data()
    with open(path + 'classification/models/{}.md'.format(model_name), 'rb') as file:
        model = pickle.load(file)

    # считываем исходный файл в .csv
    with open(filename, errors='ignore', encoding='utf-8') as file:
        p = pd.read_csv(file, delimiter=';')

    print('Загружаем данные...')

    # удаляем записи, где Текст=Nan
    p = p.dropna(subset=['Текст'])

    raw_X = [str(item) for item in p['Текст']]

    # очищаем и нормализуем данные
    X = clear_data(raw_X)

    # преобразуем данные
    x_test = tokenizer.texts_to_matrix(X, mode='tfidf')

    # получение результата классификации
    print('Строим предсказания типов объектов...')
    y_predicted = model.predict(x_test)
    y_predicted_classes = list(np.argmax(y_predicted, axis=1))
    y_predicted_proba = [max(i) for i in y_predicted]

    # переводим числа в названия категорий
    type_of_object = []
    for i in y_predicted_classes:
        for key, value in categories.items():
            if value == i:
                type_of_object.append(key)

    # добавляем новые столбцы в dataframe
    p['Тип объекта'] = type_of_object
    p['Вероятность типа объекта'] = y_predicted_proba

    # Анализ тональности текста
    dataframe = sentiment_analysis.do_sentiment_analysis(dataframe=p, raw_data=raw_X)

    # сохраняем dataframe в csv и заменяем исходный файл на новый
    dataframe.to_csv(filename, sep=';', encoding='utf-8', index=False)

    print('Данные готовы!')

    return dataframe


def handle_uploaded_file(filename):
    # ----- Можно редактировать -----
    model_name = 'MLP'  # model_name: 'MLP', 'LSTM'
    # -------------------------------
    path = BASE_DIR + STATIC_URL

    if not os.path.exists(path + 'classification/data'):
        os.makedirs(path + 'classification/data')

    if not os.path.exists(path + 'classification/models'):
        os.makedirs(path + 'classification/models')

    if not os.path.exists(path + 'classification/results'):
        os.makedirs(path + 'classification/results')

    if os.path.exists(path + 'classification/data/train_data.pkl'):
        if os.path.exists(path + 'classification/models/{}.md'.format(model_name)):
            get_report(model_name)
            visualization(model_name)
        else:
            if model_name == 'MLP':
                mlp()
                get_report(model_name)
                visualization(model_name)
            elif model_name == 'LSTM':
                lstm()
                get_report(model_name)
                visualization(model_name)
    else:
        prepare_data(filename)
        if model_name == 'MLP':
            mlp()
        elif model_name == 'LSTM':
            lstm()
        get_report(model_name)
        visualization(model_name)

    return filename
