import os

import pandas as pd
from UrbanClassifier.settings import BASE_DIR, MEDIA_URL
from classification.classification import predict_all_and_save
from classification.models import File


def last_raw_file():
    """
    Get last added raw data
    :return: one FileField object
    """
    max_id = File.objects.latest('pk').id
    return File.objects.filter(pk=max_id, is_raw=True)[0]


def last_ready_file():
    """
    Get last modified data
    :return: one FileField object
    """
    max_id = File.objects.latest('pk').id
    return File.objects.filter(pk=max_id, is_raw=False)[0]


def get_file(is_raw=True):
    """

    :param is_raw: by default it is True
    :return: str, path of file
    """
    alt_path = BASE_DIR + MEDIA_URL
    if is_raw:
        file = str(last_raw_file().file)
    else:
        file = str(last_ready_file().file)
    file = alt_path + file
    return file


def get_filename(is_raw=True):
    """

    :param is_raw: by default it is True
    :return: str, filename
    """
    if is_raw:
        return os.path.basename(last_raw_file().file.name)
    else:
        return os.path.basename(last_ready_file().file.name)


def update_file():
    """
    Change raw flag into modified for file
    :return:
    """
    file = last_raw_file()
    file.is_raw = False
    file.save()


def make_prediction(model_name):
    """
    Read data and make classification and sentiment analysis

    :param model_name: str, MLP or LSTM
    :return: DataFrame
    """
    pred = predict_all_and_save(filename=get_file(), model_name=model_name)
    # сохраняем в БД, что наш файл обработан
    update_file()
    return pred


def make_statistics(dataframe):
    """
    Read data and make statistics

    :param dataframe: DataFrame
    :return: DataFrame
    """
    # Здание
    building = len(dataframe[dataframe['Тип объекта'] == 'здание'].index)
    building_pos = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'здание') & (
            dataframe['Тональность'] == 'positive')].index) / building * 100))
    building_neg = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'здание') & (
            dataframe['Тональность'] == 'negative')].index) / building * 100))
    building_N = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'здание') & (
            dataframe['Тональность'] == 'neutral')].index) / building * 100))
    # Двор
    courtyard = len(dataframe[dataframe['Тип объекта'] == 'двор'].index)
    courtyard_pos = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'двор') & (
            dataframe['Тональность'] == 'positive')].index) / courtyard * 100))
    courtyard_neg = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'двор') & (
            dataframe['Тональность'] == 'negative')].index) / courtyard * 100))
    courtyard_N = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'двор') & (
            dataframe['Тональность'] == 'neutral')].index) / courtyard * 100))
    # Дорога
    road = len(dataframe[dataframe['Тип объекта'] == 'дорога'].index)
    road_pos = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'дорога') & (
            dataframe['Тональность'] == 'positive')].index) / road * 100))
    road_neg = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'дорога') & (
            dataframe['Тональность'] == 'negative')].index) / road * 100))
    road_N = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'дорога') & (
            dataframe['Тональность'] == 'neutral')].index) / road * 100))
    # Территория озеленения
    green_zone = len(dataframe[dataframe['Тип объекта'] == 'территория озеленения'].index)
    green_zone_pos = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'территория озеленения') & (
            dataframe['Тональность'] == 'positive')].index) / green_zone * 100))
    green_zone_neg = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'территория озеленения') & (
            dataframe['Тональность'] == 'negative')].index) / green_zone * 100))
    green_zone_N = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'территория озеленения') & (
            dataframe['Тональность'] == 'neutral')].index) / green_zone * 100))
    # Малая архитектурная форма
    maf = len(dataframe[dataframe['Тип объекта'] == 'малая архитектурная форма'].index)
    maf_pos = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'малая архитектурная форма') & (
            dataframe['Тональность'] == 'positive')].index) / maf * 100))
    maf_neg = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'малая архитектурная форма') & (
            dataframe['Тональность'] == 'negative')].index) / maf * 100))
    maf_N = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'малая архитектурная форма') & (
            dataframe['Тональность'] == 'neutral')].index) / maf * 100))
    # Водный объект
    water_object = len(dataframe[dataframe['Тип объекта'] == 'водный объект'].index)
    water_object_pos = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'водный объект') & (
            dataframe['Тональность'] == 'positive')].index) / water_object * 100))
    water_object_neg = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'водный объект') & (
            dataframe['Тональность'] == 'negative')].index) / water_object * 100))
    water_object_N = '{:.2f}%'.format((len(dataframe[(dataframe['Тип объекта'] == 'водный объект') & (
            dataframe['Тональность'] == 'neutral')].index) / water_object * 100))

    # Формирование таблицы данных
    data = {
        'Тип объекта': ['Здание', 'Двор', 'Дорога', 'Тер. озел', 'МАФ', 'Вод. объект'],
        'Всего': [building, courtyard, road, green_zone, maf, water_object],
        '+': [building_pos, courtyard_pos, road_pos, green_zone_pos, maf_pos, water_object_pos],
        '-': [building_neg, courtyard_neg, road_neg, green_zone_neg, maf_neg, water_object_neg],
        'N': [building_N, courtyard_N, road_N, green_zone_N, maf_N, water_object_N],
    }
    statistics = pd.DataFrame(data=data)

    return statistics
