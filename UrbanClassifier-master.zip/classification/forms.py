from django.forms import ModelForm

from classification.models import File


# Create the form class.
class FileForm(ModelForm):
    class Meta:
        model = File
        fields = ['file']
