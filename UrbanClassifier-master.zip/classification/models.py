from django.db import models


class File(models.Model):
    file = models.FileField(upload_to='data/classification/', verbose_name='Файл')
    date = models.DateTimeField(auto_now=True, verbose_name='Дата')
    is_raw = models.BooleanField(default=True, verbose_name='Исходный файл')
