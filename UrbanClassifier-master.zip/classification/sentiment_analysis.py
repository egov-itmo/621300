import os

from UrbanClassifier.settings import BASE_DIR, STATIC_URL
from dostoevsky.models import FastTextSocialNetworkModel
from dostoevsky.tokenization import RegexTokenizer


def do_sentiment_analysis(dataframe, raw_data):
    """
    :return: new dataframe with sentiments
    """
    # загружаем данные
    path = BASE_DIR + STATIC_URL
    if not os.path.exists(path + 'sentiment_analysis/data'):
        os.makedirs(path + 'sentiment_analysis/data')

    if not os.path.exists(path + 'sentiment_analysis/results'):
        os.makedirs(path + 'sentiment_analysis/results')

    # определяем токенизатор и модель
    tokenizer = RegexTokenizer()
    model = FastTextSocialNetworkModel(tokenizer=tokenizer, lemmatize=True)

    print('Строим предсказания тональности...')
    predictions = model.predict(raw_data, k=2)  # type: list
    sentiment = []  # значения тональности
    sentiment_proba = []  # вероятность

    for i in predictions:  # type: dict
        key, value = list(i.items())[0]  # выбор наиболее вероятного решения
        sentiment.append(key)
        sentiment_proba.append(value)

    # сохраняем результат в файл
    # добавляем новые столбцы в dataframe
    dataframe['Тональность'] = sentiment
    dataframe['Вероятность тональности'] = sentiment_proba

    return dataframe
