from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='Главная'),
    path('make_prediction', views.make_prediction, name='Сделать прогноз'),
    path('download', views.download_csv, name='Скачать файл CSV'),
]
