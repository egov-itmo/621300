import classification.controllers as controllers
import pandas as pd
from django.http import HttpResponseRedirect, HttpResponse, JsonResponse
from django.shortcuts import render
from django.utils.encoding import smart_str

from .forms import FileForm


def index(request):
    form = FileForm()
    file_result = ''
    if request.method == 'POST':
        form = FileForm(request.POST, request.FILES)
        if form.is_valid():
            # сохраняем файл в БД и в хранилище
            form.save()
            file_result = 'Файл {} успешно загружен!'.format(request.FILES['file'].name)
            return HttpResponseRedirect('/')

    if file_result:
        results = {'form': form, 'file_result': file_result}
    else:
        results = {'form': form}
    return render(request, 'index.html', results)


def make_prediction(request):
    if request.is_ajax():
        data = controllers.make_prediction(model_name='MLP')
        # меняем формат dataframe в HTML таблицу для вывода
        data_html = data.to_html(max_rows=10, justify='center', na_rep='', index=False,
                                 classes=('table', 'table-sm', 'table-hover', 'table-bordered'))
        # считаем и выводим статистику в HTML таблицу
        statistics = controllers.make_statistics(dataframe=data)
        cnt_all = data.shape[0]  # кол-во всех сообщений
        statistics_html = statistics.to_html(justify='center', na_rep='', index=False,
                                             classes=('table', 'table-sm', 'table-hover', 'table-bordered'))

        result = {'csv_table': data_html, 'cnt_all': cnt_all, 'statistics': statistics_html}
        return JsonResponse(result, safe=True)


def download_csv(request):
    if request.method == 'GET':
        file_name = controllers.get_filename(is_raw=False)
        path_to_file = controllers.get_file(is_raw=False)

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename=%s' % smart_str(file_name)

        with open(path_to_file, errors='ignore', encoding='utf-8') as file:
            dataframe = pd.read_csv(file, delimiter=';')

        dataframe.to_csv(response, sep=';', encoding='utf-8', index=False)

        return response
